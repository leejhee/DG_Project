Visual Studio 기준 : 도구 -> NuGet 패키지 관리자 -> 패키지 관리자 콘솔
PM> 에 입력

1 ExcelDataReader

1.1 ExcelDataReader 패키지 설치

Install-Package ExcelDataReader
Install-Package System.Text.Encoding.CodePages
Install-Package ExcelDataReader.DataSet


2 Spire.Xls

2.2 Spire.Xls 패키지 설치

Install-Package Spire.XLS
